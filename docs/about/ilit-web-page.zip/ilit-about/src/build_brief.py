#!/usr/bin/env python3
"""Builds ilit-brief.html with hand-laid inline SVG diagrams."""
import html

import os
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
E = html.escape

class Svg:
    def __init__(self, key, w, h, label):
        self.key, self.w, self.h, self.label = key, w, h, label
        self.parts = []
    def marker(self):
        k = self.key
        return (f'<defs><marker id="{k}-a" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
                f'<path d="M0,0 L10,5 L0,10 z" fill="currentColor"/></marker>'
                f'<marker id="{k}-h" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto-start-reverse">'
                f'<path d="M0,0 L10,5 L0,10 z" class="fa"/></marker></defs>')
    def box(self, x, y, w, h, title, lines=(), cls="bx", tcls="tt", size=13.5):
        p = [f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="6" class="{cls}"/>']
        n = 1 + len(lines)
        lh = 16
        top = y + h / 2 - (n - 1) * lh / 2 + 4.5
        p.append(f'<text x="{x + w/2}" y="{top}" text-anchor="middle" class="{tcls}" font-size="{size}">{E(title)}</text>')
        for i, ln in enumerate(lines):
            p.append(f'<text x="{x + w/2}" y="{top + (i+1)*lh}" text-anchor="middle" class="ts" font-size="12">{E(ln)}</text>')
        self.parts.append("".join(p))
    def line(self, pts, label=None, lx=None, ly=None, dashed=False, hl=False, anchor="middle", arrow=True):
        d = " ".join(f"{x},{y}" for x, y in pts)
        cls = "ln" + (" dash" if dashed else "") + (" lnh" if hl else "")
        m = f' marker-end="url(#{self.key}-{"h" if hl else "a"})"' if arrow else ""
        self.parts.append(f'<polyline points="{d}" class="{cls}"{m}/>')
        if label:
            self.parts.append(f'<text x="{lx}" y="{ly}" text-anchor="{anchor}" class="tl" font-size="11.5">{E(label)}</text>')
    def text(self, x, y, s, cls="ts", size=12, anchor="middle", weight=None):
        w = f' font-weight="{weight}"' if weight else ""
        self.parts.append(f'<text x="{x}" y="{y}" text-anchor="{anchor}" class="{cls}" font-size="{size}"{w}>{E(s)}</text>')
    def raw(self, s):
        self.parts.append(s)
    def render(self, caption, minw=680):
        return (f'<figure><div class="svgwrap"><svg viewBox="0 0 {self.w} {self.h}" role="img" aria-label="{E(self.label)}" style="min-width:{minw}px">'
                + self.marker() + "".join(self.parts) + f'</svg></div><figcaption>{caption}</figcaption></figure>')

# ---------- Figure 1: how it works ----------
f1 = Svg("f1", 940, 300, "Public sources are collected, read, linked, and turned into answers for analysts")
cols = [20, 210, 400, 590, 780]
f1.text(95, 22, "PUBLIC SOURCES", "cap", 11)
f1.text(285, 22, "1 · COLLECT", "cap", 11); f1.text(475, 22, "2 · READ", "cap", 11)
f1.text(665, 22, "3 · CONNECT", "cap", 11); f1.text(855, 22, "ANSWERS", "cap", 11)
for i, (t, s) in enumerate([("Federal Court dockets", "every immigration file"), ("Court decisions", "FC, FCA, SCC, RPD"), ("Laws and guidance", "IRPA, IRPR, CBSA, IRB")]):
    f1.box(20, 42 + i * 82, 150, 64, t, [s])
f1.box(210, 42, 150, 228, "Keep the original", ["exactly as published,", "with where and when", "it came from"], cls="bx")
f1.box(400, 42, 150, 228, "Read it", ["paragraphs", "judge and outcome", "did the Minister win", "citations", "laws referenced", "docket steps"], cls="bx")
f1.box(590, 42, 150, 228, "Connect it", ["file ↔ decision", "decision ↔ authority", "citation ↔ exact", "paragraph cited"], cls="bxh", tcls="tth")
for i, t in enumerate(["Where a file stands", "Which authorities matter", "What a memo is missing", "How arguments fared"]):
    f1.box(780, 42 + i * 58, 150, 46, t, [], size=12.5)
for i in range(3):
    f1.line([(170, 74 + i * 82), (206, 74 + i * 82)])
f1.line([(360, 156), (396, 156)])
f1.line([(550, 156), (586, 156)])
for i in range(4):
    f1.line([(740, 156), (760, 156), (760, 65 + i * 58), (776, 65 + i * 58)])
FIG1 = f1.render("<strong>How iLit works.</strong> It collects public court records, keeps the originals untouched, reads them into structured facts, connects them to each other, and answers the questions analysts ask. Every answer can be traced back to the original page.", 720)

# ---------- Figure 2: three kinds of information ----------
f2 = Svg("f2", 900, 280, "Dockets, decisions and authorities are joined by file number and by citation")
f2.box(20, 40, 230, 110, "Federal Court dockets", ["316,940 immigration files", "3.6 million entries"], cls="bxd", tcls="ttd", size=14.5)
f2.box(335, 40, 230, 110, "Decisions with reasons", ["about 61,000 decisions", "split into paragraphs"], cls="bx", size=14.5)
f2.box(650, 40, 230, 110, "Authorities cited", ["1.44 million citations", "934,000 linked to the case"], cls="bxh", tcls="tth", size=14.5)
f2.line([(250, 95), (331, 95)], "court file no.", 291, 86)
f2.line([(565, 95), (646, 95)], "citation", 605, 86)
f2.text(135, 178, "What happened", "tt", 13.5); f2.text(135, 196, "leave, stays, hearings, outcome")
f2.text(450, 178, "Why it happened", "tt", 13.5); f2.text(450, 196, "the Court’s reasoning, judge, result")
f2.text(765, 178, "What the Court relied on", "tt", 13.5); f2.text(765, 196, "cases and laws, down to the paragraph")
f2.line([(135, 214), (135, 250), (765, 250), (765, 218)], dashed=True)
f2.text(450, 268, "next: which authorities decide challenges to CBSA decisions versus IRB decisions", "tl", 11.5)
FIG2 = f2.render("<strong>Three kinds of information, joined.</strong> CanLII has only the middle box. iLit connects each decision to its court file and to everything it cites, so you can move from “what happened” to “why” to “on what authority” in a click.")

# ---------- Figure 3: why the docket matters ----------
f3 = Svg("f3", 900, 210, "In a sample of 15,000 files, about two in three were refused leave, usually without reasons")
X0, W = 20, 860
segs = [(0.651, "Leave refused · 65%", "bard"), (0.155, "Granted · 16%", "barh"), (0.194, "Unclear · 19%", "barm")]
x = X0
for frac, lab, cls in segs:
    w = W * frac
    f3.raw(f'<rect x="{x:.1f}" y="40" width="{w:.1f}" height="54" class="{cls}"/>')
    f3.text(x + 12, 72, lab, "tbar", 13, "start", 600)
    x += w
f3.text(20, 26, "15,000 Federal Court immigration files, 500 per year, 1993–2022", "ts", 12, "start")
wr = W * 0.651
f3.raw(f'<polyline points="20,106 20,116 {20+wr:.1f},116 {20+wr:.1f},106" class="ln" fill="none"/>')
f3.text(20 + wr / 2, 138, "Usually decided with no written reasons.", "tt", 13.5)
f3.text(20 + wr / 2, 156, "Invisible to any tool built only on published decisions, including CanLII.")
f3.text(20 + wr / 2, 184, "iLit sees every one of them through the docket.", "tth", 13.5)
FIG3 = f3.render("<strong>Why the docket matters.</strong> Most immigration files end without a published decision. Measuring outcomes or workload from decisions alone describes a small, skewed slice. The docket gives the whole picture. Sample from iLit’s docket classifier (earlier version); illustrative, not an official statistic.", 700)

# ---------- Figure 4: life of a file ----------
f4 = Svg("f4", 940, 330, "The steps of a Federal Court immigration file that iLit tracks")
row, h = 40, 64
xs = [20, 205, 390, 575, 760]
titles = [("Application filed", ["date, applicant"]), ("Record filed", ["file perfected"]), ("Leave decision", ["granted or refused", "judge"]),
          ("Hearing", ["scheduled or held"]), ("Judgment", ["granted or dismissed", "judge"])]
for (t, l), x in zip(titles, xs):
    f4.box(x, row, 160, h, t, l, cls="bxh" if t == "Leave decision" else "bx")
for a, b in zip(xs, xs[1:]):
    f4.line([(a + 160, row + h / 2), (b - 4, row + h / 2)])
f4.text(482 + 60, row + h / 2 - 8, "granted", "tl", 11.5)
f4.box(390, 170, 160, 54, "File closed", ["leave refused"], cls="bxd", tcls="ttd")
f4.line([(470, row + h), (470, 166)], "refused", 480, 142, anchor="start")
f4.box(205, 170, 160, 54, "Discontinued", ["or withdrawn"], cls="bxm")
f4.line([(285, row + h), (285, 166)], dashed=True)
f4.box(20, 258, 900, 54, "Motions and stays of removal, tracked whenever they appear", ["type of motion, outcome, scheduled removal date and destination"], cls="bxd", tcls="ttd")
f4.line([(100, row + h), (100, 254)], dashed=True)
f4.text(575 + 170, 190, "Each step is dated, linked to the", "ts", 12, "start")
f4.text(575 + 170, 206, "registry entry it came from, and", "ts", 12, "start")
f4.text(575 + 170, 222, "rolled up into one card per file.", "ts", 12, "start")
FIG4 = f4.render("<strong>Following a file.</strong> iLit reads the free-text docket of every Federal Court immigration file and turns it into these steps, in English and French. Enter a file number and see where it stands in seconds.", 720)

# ---------- Figure 5: citation journey ----------
f5 = Svg("f5", 940, 330, "A citation in a decision becomes a link to the exact paragraph and then feeds analysis")
steps = [("In the decision", ["“Vavilov, at para 99”"]), ("Recognised", ["as a short-form citation"]), ("Matched", ["to the full name earlier", "in the same decision"]),
         ("Linked", ["to Vavilov in the library"]), ("Pinpointed", ["to paragraph 99", "shown on click"])]
for i, (t, l) in enumerate(steps):
    x = 20 + i * 185
    f5.box(x, 30, 160, 70, t, l, cls="bxh" if i == 4 else "bx", tcls="tth" if i == 4 else "tt")
    if i:
        f5.line([(x - 25, 65), (x - 4, 65)])
f5.box(20, 150, 900, 40, "Done for 1.44 million citations; pinpointed to the paragraph for 183,010 of them", [], cls="bxm", size=13)
f5.line([(470, 100), (470, 146)])
qs = ["Is this authority emerging or declining?", "How does the Minister fare when it’s cited?", "What do similar decisions cite that this one doesn’t?", "Which chain of citations led here?"]
def wrap(s, n=26):
    out, cur = [], ""
    for w in s.split():
        if len(cur) + len(w) + 1 > n and cur:
            out.append(cur); cur = w
        else:
            cur = (cur + " " + w).strip()
    out.append(cur); return out
for i, q in enumerate(qs):
    x = 20 + i * 228
    lines = wrap(q)
    f5.box(x, 240, 216, 64, lines[0], lines[1:], tcls="tt", size=13)
    f5.line([(x + 108, 190), (x + 108, 236)])
FIG5 = f5.render("<strong>How a citation becomes intelligence.</strong> Most tools stop at “this case cites that case”. iLit knows exactly where each citation sits, which paragraph it points to, and adds them up across the whole library to answer questions no single decision can.", 720)

# ---------- Figure 6: AI paragraph flow ----------
f6 = Svg("f6", 940, 250, "Rules and AI label each paragraph, rules verify, and paragraphs are linked to citations")
st = [("A paragraph", ["from a decision"], "bx", "tt"), ("Rules", ["find its role:", "issue, position, test…"], "bx", "tt"),
      ("AI reads it", ["adds a topic and", "a plain explanation"], "bxh", "tth"), ("Rules check", ["real paragraph?", "real citations?"], "bx", "tt"),
      ("Linked", ["to the citations", "inside it"], "bx", "tt")]
for i, (t, l, c, tc) in enumerate(st):
    x = 20 + i * 185
    f6.box(x, 30, 160, 76, t, l, cls=c, tcls=tc)
    if i:
        f6.line([(x - 25, 68), (x - 4, 68)])
f6.box(575, 170, 160, 50, "Marked “not found”", ["never guessed"], cls="bxm")
f6.line([(655, 106), (655, 166)], "fails", 664, 142, dashed=True, anchor="start")
f6.box(760, 170, 160, 50, "Search and compare", ["across decisions"], cls="bxh", tcls="tth")
f6.line([(840, 106), (840, 166)])
f6.text(20, 190, "AI proposes. Rules verify.", "tth", 15, "start", 600)
f6.text(20, 210, "AI output is a separate, labelled layer and never", "ts", 12, "start")
f6.text(20, 226, "changes the source text, citations or facts.", "ts", 12, "start")
FIG6 = f6.render("<strong>AI that reads paragraphs.</strong> Each paragraph gets a meaning (what it is doing and what it is about) and is tied to the authorities cited in it. Done so far for about 93% of the paragraphs in 300 core decisions (13,424 paragraph records), with 6,260 citations linked to the paragraphs that use them.", 720)

# ---------- Figure 7: now vs with hardware ----------
f7 = Svg("f7", 940, 300, "Today a public AI reads only public decisions; with local hardware the AI runs inside the department and can read internal documents")
f7.text(220, 22, "TODAY", "cap", 11); f7.text(710, 22, "WITH FUNDED HARDWARE", "cap", 11)
f7.box(20, 60, 170, 60, "iLit", ["public decisions"], cls="bx")
f7.box(270, 60, 170, 60, "Public AI service", ["outside the department"], cls="bxm")
f7.line([(190, 90), (266, 90)], "public text only", 228, 80)
f7.raw('<line x1="230" y1="40" x2="230" y2="150" class="ln dash"/>')
f7.box(20, 170, 420, 110, "Internal documents", ["cannot be sent to a public AI", "", "Uploaded documents get rule-based", "citation checks only, in memory"], cls="bxd", tcls="ttd")
f7.raw('<rect x="490" y="40" width="430" height="245" rx="10" class="zone"/>')
f7.text(705, 60, "Department network: nothing leaves", "tth", 12.5)
f7.box(510, 80, 180, 60, "iLit", ["public case law"], cls="bx")
f7.box(720, 80, 180, 60, "Local AI", ["on departmental hardware"], cls="bxh", tcls="tth")
f7.line([(690, 110), (716, 110)])
f7.box(510, 190, 390, 76, "Internal documents", ["draft submissions, precedent memos, briefing notes", "read paragraph by paragraph and linked to the case law"], cls="bxd", tcls="ttd")
f7.line([(810, 140), (810, 186)], "reads", 818, 166, anchor="start")
f7.line([(600, 140), (600, 186)], "links to", 608, 166, anchor="start")
FIG7 = f7.render("<strong>What local hardware unlocks.</strong> Today a low-cost public AI is used, and only on public decisions. iLit is being built so the same AI step can run on a local model inside the department. That opens live AI analysis of the Division’s own internal documents, which a public service can never be given.", 720)

# ---------- Figure 8: funding tiers ----------
f8 = Svg("f8", 940, 330, "Three unofficial funding tiers, each building on the one below: about 2 thousand dollars for AI services, about 5 thousand for a dedicated machine, 15 to 20 thousand for a Mac Studio")
tiers = [
    ("≈ $2K", "Tier 1 · Keep building", ["subscriptions and", "more AI API use", "for the next few months"], "AI meaning for far more", "of the library, faster", "bx", "tt"),
    ("≈ $5K", "Tier 2 · Its own machine", ["used MacBook Pro, 32 GB,", "running a capable", "local AI model"], "Off my personal computer;", "AI step tested locally", "bxh", "tth"),
    ("$15–20K", "Tier 3 · Built to last", ["powerful Mac Studio", "with room for larger", "AI models"], "Large local models; internal", "docs once approved", "bxd", "ttd"),
]
base = 300
for i, (price, title, lines, u1, u2, cls, tcls) in enumerate(tiers):
    x = 30 + i * 305
    h = 185 + i * 50
    y = base - h
    f8.raw(f'<rect x="{x}" y="{y}" width="270" height="{h}" rx="6" class="{cls}"/>')
    f8.text(x + 135, y + 34, price, tcls, 24, weight=650)
    f8.text(x + 135, y + 58, title, "tt", 13.5)
    for j, l in enumerate(lines):
        f8.text(x + 135, y + 80 + j * 16, l)
    f8.text(x + 135, base - 34, u1, "tl", 11.5)
    f8.text(x + 135, base - 18, u2, "tl", 11.5)
    if i < 2:
        f8.line([(x + 272, base - h / 2 - 10), (x + 303, base - h / 2 - 38)], dashed=True)
f8.raw(f'<line x1="20" y1="{base + 1}" x2="920" y2="{base + 1}" class="ln"/>')
f8.text(470, base + 22, "Each tier includes the one before it. Italic lines show what it unlocks.", "ts", 12)
FIG8 = f8.render("<strong>An unofficial funding idea, in three sizes.</strong> Any of them speeds the project up; none of them commits anyone to adopting it. Figures are rough, in Canadian dollars, and come from the pricing research.", 700)

# ---------- Figure 9: forward ingestion loop ----------
f9 = Svg("f9", 940, 330, "New court activity is checked, stored once, read and linked, then the file is scheduled for its next check")
f9.text(470, 22, "HOW NEW CASES COME IN", "cap", 11)
f9.box(20, 50, 190, 78, "New court activity", ["new decisions,", "new docket entries"], cls="bxd", tcls="ttd")
f9.box(260, 50, 190, 78, "Check what's due", ["only files that are", "stale or still open"])
f9.box(500, 50, 190, 78, "Keep the original", ["fingerprinted;", "unchanged pages skipped"])
f9.box(740, 50, 180, 78, "Read and link", ["docket steps, citations,", "pinpoints, search index"], cls="bxh", tcls="tth")
f9.box(740, 200, 180, 78, "Answers updated", ["file status, trends,", "search"])
f9.box(380, 200, 250, 78, "Next check scheduled", ["each file records when it was", "last checked and when it's due"])
f9.line([(210, 89), (256, 89)]); f9.line([(450, 89), (496, 89)]); f9.line([(690, 89), (736, 89)])
f9.line([(830, 128), (830, 196)])
f9.line([(740, 239), (634, 239)])
f9.line([(380, 239), (355, 239), (355, 132)], "loop", 346, 190, anchor="end", dashed=True)
f9.box(20, 200, 300, 78, "Polite by design", ["spaces out requests; stops if the", "site asks for human verification"], cls="bxm")
f9.text(470, 312, "Each step is built and has been run. Today they are started by hand; joining them into one nightly run is a next step.", "tl", 12)
FIG9 = f9.render("<strong>Designed to keep up.</strong> iLit is built to take in new decisions and new docket activity as they appear, without redoing work: each step only handles what is new or changed, and can pick up where it left off after an interruption.", 720)

CSS = open(os.path.join(HERE, "brief.css")).read()
BODY = open(os.path.join(HERE, "brief_body.html")).read()
for k, v in dict(FIG1=FIG1, FIG2=FIG2, FIG3=FIG3, FIG4=FIG4, FIG5=FIG5, FIG6=FIG6, FIG7=FIG7, FIG8=FIG8, FIG9=FIG9).items():
    BODY = BODY.replace("{{" + k + "}}", v)

FONTS = ('<link rel="preconnect" href="https://fonts.googleapis.com">\n'
         '<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>\n'
         '<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600'
         '&family=IBM+Plex+Mono:wght@400;500&family=Newsreader:opsz,wght@6..72,400;6..72,600;6..72,700&display=swap">')
FRAGMENT = f'<style>\n{CSS}</style>\n<div class="ilit-about">{BODY}</div>\n'

# 1) Drop-in fragment for the site's About tab (the site already loads the fonts).
open(os.path.join(ROOT, "ilit-about-fragment.html"), "w").write(FRAGMENT)

# 2) Standalone preview page with the site's grid background.
PAGE = f"""<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>About iLit</title>
{FONTS}
<style>
html,body{{margin:0}}
body{{background:#f1efe8;background-image:linear-gradient(rgba(32,37,34,.035) 1px,transparent 1px),linear-gradient(90deg,rgba(32,37,34,.035) 1px,transparent 1px);background-size:26px 26px;padding:32px 16px 64px}}
</style>
</head>
<body>
{FRAGMENT}</body>
</html>
"""
open(os.path.join(ROOT, "ilit-overview.html"), "w").write(PAGE)
print("ok", len(PAGE))
